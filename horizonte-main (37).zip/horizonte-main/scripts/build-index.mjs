// Genera index.html, reserva.html, 404.html, privacidad.html, robots.txt, sitemap.xml, site.webmanifest y favicon.svg
// a partir de data/dealership.json y data/vehicles.json. Sin dependencias.
// Uso: npm run build   (después: npm test)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');
const write = (f, s) => fs.writeFileSync(path.join(root, f), s);
const D = JSON.parse(read('data/dealership.json'));
const A = JSON.parse(read('data/vehicles.json'));

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const demo = D.publicacion.publicIndexing === false;
const siteUrl = D.publicacion.siteUrl ? D.publicacion.siteUrl.replace(/\/?$/, '/') : null;
const NAME = D.identity.tradeName;
const L = D.location;
const C = D.contact;
const FB = C.facebook;
const IG = `https://www.instagram.com/${C.instagram}/`;
const GNAME = D.identity.grupo;
const GWEB = D.identity.grupoWeb;
const GCAT = D.stock.catalogoUrl;
const hasSvc = (k) => D.services.published.some((x) => x.clave === k);
const fdate = (iso) => iso.split('-').reverse().join('/');
const BNASVC = D.services.published.find((s) => s.fuente.includes('bna.com.ar'));
const BNA = BNASVC.fuente;
const BNAFECHA = BNASVC.periodo;
const wa = (txt) => (C.whatsApp ? `https://wa.me/${C.whatsApp}?text=${encodeURIComponent(txt)}` : null);
const WA = wa('Hola! Quiero consultar por las unidades disponibles.');
const EXT = 'target="_blank" rel="noopener noreferrer"';
const WAFORM = C.whatsApp ? `<a class="btn p" data-wa-msg data-wa="${C.whatsApp}" href="https://wa.me/${C.whatsApp}" ${EXT}>Enviar por WhatsApp</a>` : '';
const CPBTN = `<button class="btn${C.whatsApp ? '' : ' p'}" type="submit" data-copiar-msg hidden>Copiar mensaje</button>`;
const LEYENDA_CORTA = 'Demo ilustrativa · No es el sitio oficial';
const LEYENDA = `Demo ilustrativa construida a partir de información pública. Datos y disponibilidad sujetos a confirmación por ${NAME}. No es el sitio oficial.`;
const FONTS = '@font-face{font-family:"Bricolage Grotesque";font-style:normal;font-weight:200 800;font-display:swap;src:url(fonts/bricolage-grotesque-latin.woff2) format("woff2")}\n@font-face{font-family:"Instrument Sans";font-style:normal;font-weight:400 700;font-display:swap;src:url(fonts/instrument-sans-latin.woff2) format("woff2")}\n';
const CSS = read('scripts/estilos.css').trim();

const OG = `<meta property="og:image" content="https://hnk375561-lab.github.io/horizonte/images/og-horizonte.jpg">\n<meta property="og:image:type" content="image/jpeg">\n<meta property="og:image:width" content="1200">\n<meta property="og:image:height" content="630">\n<meta property="og:image:alt" content="Horizonte Automotores · Autos y motos en María Grande, Entre Ríos">\n<meta name="twitter:card" content="summary_large_image">\n`;
const robotsMeta = demo ? '<meta name="robots" content="noindex, nofollow">\n' : '';
const canon = (p) => (siteUrl ? `<link rel="canonical" href="${siteUrl}${p}">\n<meta property="og:url" content="${siteUrl}${p}">\n` : '');

function page({ title, desc, body, file, withFonts = true, extraHead = '' }) {
  return `<!DOCTYPE html>
<html lang="es-AR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
${robotsMeta}<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
<meta name="theme-color" content="#0a1012">
<meta property="og:type" content="website">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(desc)}">
<meta property="og:locale" content="es_AR">
${OG}${canon(file === 'index.html' ? '' : file)}${withFonts ? '<link rel="manifest" href="site.webmanifest">\n<link rel="icon" type="image/png" sizes="192x192" href="images/icon-192.png">\n<link rel="apple-touch-icon" href="images/icon-180.png">\n<link rel="preload" href="fonts/bricolage-grotesque-latin.woff2" as="font" type="font/woff2" crossorigin>\n<link rel="preload" href="fonts/instrument-sans-latin.woff2" as="font" type="font/woff2" crossorigin>\n' : ''}<style>
${withFonts ? FONTS : ''}${CSS}
</style>
${extraHead}</head>
<body>
${body}
</body>
</html>
`;
}

const footer = (fuentes) => `<footer><div class="w">
<div class="ft"><div class="ft-m"><img class="lg-ft" src="images/logo-sm.png" width="360" height="144" alt=""><p class="ft-b">${esc(NAME)}</p><p>${esc(L.address)}, ${esc(L.city)}, ${esc(L.province)}</p><p class="ft-a">Antes: ${esc(L.direccionAnterior)}</p></div>
<div><p class="ft-k">Contacto</p>${C.phoneTel ? `<p><a href="tel:${C.phoneTel}">${esc(C.phone)}</a></p>` : ''}${C.whatsApp ? `<p><a href="${WA}" ${EXT}>WhatsApp ${esc(C.whatsAppDisplay)}</a></p>` : ''}${C.email ? `<p><a href="mailto:${esc(C.email)}">${esc(C.email)}</a></p>` : ''}</div>
<div><p class="ft-k">Redes</p><p><a href="${FB}" ${EXT}>Facebook</a></p><p><a href="${IG}" ${EXT}>Instagram</a></p><p><a href="${GWEB}" ${EXT}>${esc(GNAME)}</a></p></div></div>
<p class="ft-c">© 2026 ${esc(NAME)}</p>${demo ? `<p class="demo-note" data-demo-note>${esc(LEYENDA)} Datos pendientes de confirmación.</p>` : ''}${fuentes ? `<p>Fuentes: <a href="${FB}" ${EXT}>Facebook</a> · <a href="${IG}" ${EXT}>Instagram</a> · <a href="${GWEB}" ${EXT}>${esc(GNAME)}</a> · <a href="${BNA}" ${EXT}>Listado de concesionarias de Créditos Más Autos (Banco Nación, ${esc(BNAFECHA)})</a></p>` : ''}<p><a href="privacidad.html">Privacidad y avisos</a></p></div></footer>`;

const autos = A.autos;
const ctaHead = WA ? { href: WA, t: 'WhatsApp' } : { href: FB, t: 'Facebook' };
const header = (pre = '', skip = '#unidades') => `<a class="skip" href="${skip}">Saltar al contenido</a>
<header class="site-header${pre ? ' site-header--inner' : ' site-header--home'}"><div class="w"><a class="mark" href="./" aria-label="${esc(NAME)}, inicio"><img class="lg-img" src="images/logo.png" width="900" height="360" alt="${esc(NAME)}"></a>
<nav class="site-nav" id="site-nav" aria-label="Principal"><a href="${pre}#horarios">Horarios</a><a href="${pre}#unidades">Unidades</a><a href="${pre}#financiacion">Financiación</a><a href="${pre}#guia">Guía</a><a href="${pre}#preguntas">Preguntas</a><a href="${pre}#nosotros">Nosotros</a><a href="${pre}#contacto">Contacto</a><a href="${pre}#tu-usado">Tu usado</a><a href="${pre}#busqueda">Tu búsqueda</a><a href="${pre}#visita">Visita</a></nav>
<button class="menu-toggle" type="button" aria-expanded="false" aria-controls="site-nav" data-menu-toggle><span class="menu-icon" aria-hidden="true"></span><span>Menú</span></button>
<div class="hc"><a class="btn p sm" href="${ctaHead.href}" ${EXT}>${ctaHead.t}</a></div></div></header>
${demo ? `<p class="demo"><span>${esc(LEYENDA_CORTA)}</span></p>` : ''}`;

// ---- servicios que se muestran en el panel lateral de la ficha (salen de services.published) ----
const SERV_FICHA = [
  hasSvc('permuta') ? 'Tu usado como parte de pago' : '',
  hasSvc('tasacion') ? 'Tasación sin cargo' : '',
  'Financiación: figuramos en Créditos Más Autos (Banco Nación)',
  hasSvc('garantia') ? 'Revisión técnica y garantía' : '',
].filter(Boolean);

// ---- unidades ----
const fmt = (n) => n.toLocaleString('es-AR');
const norm = (t) => String(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const jsonSafe = (o) => JSON.stringify(o).replace(/</g, '\\u003c');
// Muestra de color solo para dibujar el punto junto al nombre del color publicado; no es un dato de la ficha.
const SW = { blanco: '#f1f1ee', negro: '#161b1d', rojo: '#c21f1f', 'gris plata': '#b4bbbe', 'gris oscuro': '#4b5256', plata: '#b4bbbe', gris: '#8a9296', azul: '#1e4a8c', verde: '#2f6b45', bordo: '#6d1a2a', beige: '#cdbb98', dorado: '#b99a45', naranja: '#d9742a', amarillo: '#e5c717', marron: '#6b4a32' };
const swatch = (c) => SW[norm(c || '')] || null;
const marcaDe = (a) => a.marca || a.titulo.split(' ')[0];
const sinMarca = (a) => { const m = marcaDe(a); return a.titulo.startsWith(m + ' ') ? a.titulo.slice(m.length + 1) : a.titulo; };
const consultaHref = (a) => wa(`Hola! Me interesa el ${a.titulo}${a.anio ? ' ' + a.anio : ''}.`) || a.url;
// Fotos opcionales: no se inventan ni se toman de terceros; solo se publican si data/ las autoriza.
const mediaDe = (a) => (Array.isArray(a.fotos) ? a.fotos : Array.isArray(a.imagenes) ? a.imagenes : Array.isArray(a.galeria) ? a.galeria : []).map((x) => typeof x === 'string' ? { src: x, alt: a.titulo } : x).filter((x) => x && (x.src || x.url)).map((x) => ({ src: x.src || x.url, srcset: x.srcset || '', alt: x.alt || a.titulo, tipo: x.tipo || '' }));
const mediaTag = (a, i) => { const m = mediaDe(a)[0]; return m ? `<figure class="car-ph"><img src="${esc(m.src)}"${m.srcset ? ` srcset="${esc(m.srcset)}"` : ''} sizes="(max-width: 700px) 100vw, 320px" width="${m.width || 900}" height="${m.height || 600}" loading="${i === 0 ? 'eager' : 'lazy'}"${i === 0 ? ' fetchpriority="high"' : ''} decoding="async" alt="${esc(m.alt)}"></figure>` : ''; };
const IC = {
  wa: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20l1.3-4A8 8 0 1 1 8 18.7z"/><path d="M9 9c0 3 3 6 6 6l1-1.5-2-1-1 .8a4 4 0 0 1-2-2l.8-1-1-2z"/></svg>',
  mail: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="5.5" width="17" height="13" rx="1.5"/><path d="M4 7l8 6 8-6"/></svg>',
  tel: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A15 15 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg>',
  share: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8.2 10.8l7.6-4.6M8.2 13.2l7.6 4.6"/></svg>',
};
const mailHref = (a) => C.email ? `mailto:${C.email}?subject=${encodeURIComponent('Consulta por ' + a.titulo + (a.anio ? ' ' + a.anio : ''))}&body=${encodeURIComponent('Hola! Me interesa el ' + a.titulo + (a.anio ? ' ' + a.anio : '') + '. ¿Me pasan disponibilidad, precio y formas de pago? Gracias.')}` : null;
const quick = (a, i) => {
  const t = esc(a.titulo);
  const items = [
    C.whatsApp ? `<a href="${esc(consultaHref(a))}" ${EXT} aria-label="WhatsApp: ${t}" title="WhatsApp">${IC.wa}<span>WhatsApp</span></a>` : '',
    C.email ? `<a href="${esc(mailHref(a))}" aria-label="Correo: ${t}" title="Correo">${IC.mail}<span>Correo</span></a>` : '',
    C.phoneTel ? `<a href="tel:${C.phoneTel}" aria-label="Llamar por ${t}" title="Llamar">${IC.tel}<span>Llamar</span></a>` : '',
    `<button type="button" data-share="${i}" aria-label="Compartir ${t}" title="Compartir" hidden>${IC.share}<span>Compartir</span></button>`,
  ].filter(Boolean).join('');
  return `<div class="car-q" role="group" aria-label="Contacto rápido">${items}</div>`;
};
const card = (a) => {
  const i = autos.indexOf(a);
  const marca = marcaDe(a);
  const sw = swatch(a.color);
  const fila = (k, v) => (v ? `<div><dt>${k}</dt><dd>${v}</dd></div>` : '');
  const pr = a.precio ? `<p class="pr">${a.precio.moneda === 'USD' ? 'US$ ' : '$ '}${fmt(a.precio.monto)}</p><p class="n">Precio publicado el ${esc(fdate(a.precio.fecha))}; puede haber cambiado.</p>` : '<p class="pr">Consultar precio</p>';
  const busca = norm([a.titulo, marca, a.modelo, a.version, a.cilindrada, a.color, a.anio].filter((x) => x !== undefined && x !== null && x !== '').join(' '));
  return `<li class="car reveal" style="--reveal-delay:${Math.min(i,5)*60}ms" data-t="${esc(busca)}" data-i="${i}">
${mediaTag(a, i)}
<div class="car-h"><span class="car-b">${esc(marca)}</span><label class="car-c" hidden><input type="checkbox" value="${i}" aria-label="Comparar ${esc(a.titulo)}"><span>Comparar</span></label></div>
<h3>${esc(sinMarca(a))}</h3>
<div class="car-s"><p><b${a.anio == null ? ' class="nd"' : ''}>${a.anio != null ? a.anio : 'Sin dato'}</b><small>Año</small></p><p><b${a.km == null ? ' class="nd"' : ''}>${a.km != null ? fmt(a.km) : 'No publicado'}</b><small>Kilómetros</small></p></div>
<dl class="sp">${fila('Caja', a.transmision ? esc(a.transmision) : '')}${fila('Combustible', a.combustible ? esc(a.combustible) : '')}${fila('Color', a.color ? `${sw ? `<i class="sw" style="--sw:${sw}"></i>` : ''}${esc(a.color)}` : '')}</dl>
<div class="car-f">${pr}${a.nota ? `<p class="n">${esc(a.nota)}</p>` : ''}<button class="btn sm ficha-trigger" type="button" data-ficha="${i}" aria-label="Ver la ficha completa de ${esc(a.titulo)}">Ver la ficha completa</button><button class="btn sm gallery-trigger" type="button" data-gallery="${i}" hidden>Ver galería</button><a class="btn sm" href="${esc(consultaHref(a))}" ${EXT} aria-label="Consultar por ${esc(a.titulo)}">${WA ? 'Reservar esta unidad' : 'Consultar por Facebook'}</a>${quick(a, i)}</div>
</li>`;
};
const catData = autos.map((a, i) => ({ i, titulo: a.titulo, media: mediaDe(a), marca: marcaDe(a), modelo: a.modelo || null, cilindrada: a.cilindrada || null, version: a.version || null, anio: a.anio ?? null, km: a.km ?? null, carroceria: a.carroceria || null, id: a.id || null, nota: a.nota || null, publicado: a.publicadoEl || null, hrefFin: wa(`Hola! Quiero consultar financiación para el ${a.titulo}${a.anio ? ' ' + a.anio : ''}.`), hrefVisita: wa(`Hola! Quiero coordinar una visita y prueba de manejo del ${a.titulo}${a.anio ? ' ' + a.anio : ''}.`), mail: mailHref(a), transmision: a.transmision || null, combustible: a.combustible || null, color: a.color || null, sw: swatch(a.color), precio: a.precio || null, url: a.url, href: consultaHref(a) }));
const unidades = autos.length
  ? `${autos.length > 1 ? '<div class="fx" id="tools" hidden></div>\n' : ''}<p id="sinres" class="vacio" hidden>Ninguna unidad coincide con los filtros. Sacá alguno o limpiá todos para ver las ${autos.length} unidades.</p><ul class="cars" id="cars">\n${autos.map(card).join('\n')}\n</ul>\n<script type="application/json" id="cat-data">${jsonSafe(catData)}</script>\n<script type="application/json" id="cat-ctx">${jsonSafe({ nombre: NAME, tel: C.phoneTel || null, telTxt: C.phone || null, wa: C.whatsApp ? WA : null, waTxt: C.whatsAppDisplay || null, email: C.email || null, maps: L.mapsUrl || null, dir: `${L.address}, ${L.city}, ${L.province}`, horario: D.hours.corto || null, ig: IG, fb: FB, grupo: GNAME, ciudad: L.city, servicios: SERV_FICHA })}</script>\n<p class="src">Unidades publicadas en el Instagram de @${esc(C.instagram)}${A.relevadoEl ? ` relevadas el ${esc(fdate(A.relevadoEl))}` : ''}. Precio y disponibilidad pueden haber cambiado: consultalos antes de ir.</p>\n<div class="row mt"><a class="btn p" href="${GCAT}" ${EXT}>Ver catálogo completo</a><a class="btn" href="${FB}" ${EXT}>Ver más en Facebook</a><a class="btn" href="${IG}" ${EXT}>Ver más en Instagram</a></div>`
  : `<div class="vacio"><p>Las unidades disponibles se publican con fotos en nuestra página de Facebook y en Instagram. Escribinos y te contamos disponibilidad y precio.</p><div class="row"><a class="btn p" href="${FB}" ${EXT}>Ver unidades en Facebook</a><a class="btn" href="${IG}" ${EXT}>Ver Instagram</a></div></div>`;

// ---- contacto ----
const H = D.hours;
const fh = (t) => t.replace(/^0/, '');
const rng = (r) => r.map((x) => `${fh(x[0])} a ${fh(x[1])}`).join(' y ');
const hrsRows = H.display ? H.semana.map((g) => `<tr data-dias="${g.dias.join(',')}"><th scope="row">${esc(g.etiqueta)}</th><td>${rng(g.rangos)} h</td></tr>`).join('') + (H.domingo ? `<tr data-dias="0"><th scope="row">Domingos</th><td>${esc(H.domingo)}</td></tr>` : '') : '';
const estadoP = H.display ? `<p class="estado" data-estado data-semana="${esc(JSON.stringify(H.semana))}" hidden></p>` : '';
const hrsTable = H.display ? `${estadoP}<table class="hrs"><caption class="sr">Horario de atención</caption><tbody>${hrsRows}</tbody></table>` : '';
const direccion = `${esc(L.address)}, ${esc(L.city)}, ${esc(L.province)}${L.direccionAnterior ? `<small class="ant">Antes: ${esc(L.direccionAnterior)}</small>` : ''}`;
const dl = [
  ['Dirección', direccion],
  ['Cómo llegar', `<a href="${L.mapsUrl}" ${EXT}>Abrir en Google Maps</a>`],
  C.phone ? ['Teléfono', `<a href="tel:${C.phoneTel}">${esc(C.phone)}</a>`] : null,
  C.whatsApp ? ['WhatsApp', `<a href="${WA}" ${EXT}>${esc(C.whatsAppDisplay)} · Escribinos</a>`] : null,
  C.email ? ['Correo', `<a href="mailto:${esc(C.email)}">${esc(C.email)}</a>`] : null,
  H.display ? ['Horario', hrsTable] : null,
  D.reviews.googleUrl ? ['Ficha de Google', `<a href="${D.reviews.googleUrl}" ${EXT}>Abrir ficha en Google</a>`] : null,
  ['Redes', `<a href="${FB}" ${EXT}>Facebook</a> · <a href="${IG}" ${EXT}>Instagram @${esc(C.instagram)}</a>`],
  ['Grupo', `<a href="${GWEB}" ${EXT}>${esc(GNAME)} · Concesionario Usados ${esc(L.city)}</a>`],
].filter(Boolean);

// ---- barra de datos, sucursales del grupo, preguntas ----
const bar = `<div class="bar" role="region" aria-label="Datos rápidos"><div class="w"><ul>
<li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/></svg><span class="k">Dirección</span><b>${esc(L.address.replace('Avenida', 'Av.'))}</b><small>${esc(L.city)}${L.direccionAnterior ? ` · antes ${esc(L.direccionAnterior)}` : ''}</small></li>
${C.phoneTel ? `<li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A15 15 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg><span class="k">Teléfono</span><a href="tel:${C.phoneTel}">${esc(C.phone)}</a><small>Llamanos</small></li>` : ''}
${C.whatsApp ? `<li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20l1.3-4A8 8 0 1 1 8 18.7z"/><path d="M9 9c0 3 3 6 6 6l1-1.5-2-1-1 .8a4 4 0 0 1-2-2l.8-1-1-2z"/></svg><span class="k">WhatsApp</span><a href="${WA}" ${EXT}>${esc(C.whatsAppDisplay)}</a><small>Escribinos</small></li>` : ''}
${H.display ? `<li><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3 2"/></svg><span class="k">Horario</span><b data-estado>${esc(H.corto)}</b><small>${estadoP ? 'Hora de Argentina' : ''}</small></li>` : ''}
</ul></div></div>`;

const qa = (q, a) => `<details class="dd"><summary>${q}</summary><p>${a}</p></details>`;
const faq = [
  hasSvc('permuta') ? qa('¿Reciben mi usado como parte de pago?', `Según informa ${esc(GNAME)}, sí: se reciben vehículos usados como parte de pago. Armá el mensaje en la sección «Tu usado» y envialo a la agencia.`) : '',
  hasSvc('tasacion') ? qa('¿La tasación tiene costo?', `Según informa ${esc(GNAME)} en su sitio, la tasación es sin cargo.`) : '',
  hasSvc('garantia') ? qa('¿Los autos tienen garantía?', `Los usados pasan por revisión técnica y se entregan con garantía. Las condiciones dependen de cada vehículo: consultalas por la unidad que te interese.`) : '',
  qa('¿Cómo financio?', `Ofrecemos financiación para autos y motos y figuramos en el listado de Créditos Más Autos del Banco de la Nación (${esc(BNAFECHA)}). Los montos y las condiciones dependen de la unidad y de cada solicitante.`),
  qa('¿Los precios publicados son definitivos?', `No necesariamente. Cada tarjeta muestra el precio de la ficha pública en la fecha en que se relevó: consultalo antes de ir.`),
  qa('¿Cómo coordino una visita?', `Entrá a <a href="reserva.html">Agendar visita y prueba de manejo</a>, elegí un día y una franja y enviá la consulta. No es un turno: el día y la hora se acuerdan con la agencia.`),
  H.display ? qa('¿Cuándo atienden?', `Los días y franjas, y si estamos abiertos ahora, están en la sección <a href="#horarios">Horarios</a>.`) : '',
].filter(Boolean).join('\n');
const glos = [
  ['Título del automotor', 'Documento del Registro del Automotor que acredita quién es el titular del vehículo.'],
  ['Cédula de identificación', 'Documento que habilita a circular con el vehículo. La del titular es la «cédula verde».'],
  ['Dominio', 'La patente: letras y números que identifican al vehículo.'],
  ['Informe de dominio', 'Certificado del Registro con los datos del titular y las anotaciones del vehículo, por ejemplo prendas o embargos.'],
  ['Libre deuda', 'Constancia de que no hay deuda de patentes o multas.'],
  ['Verificación policial', 'Control físico que comprueba que los números de motor y chasis coinciden con los papeles.'],
  ['Formulario 08', 'Formulario de transferencia que firman las partes cuando cambia el titular.'],
  ['Parte de pago', 'Entregar tu usado como parte del precio de otra unidad.'],
].map(([t, d]) => qa(t, d)).join('\n');
const secPreguntas = `
<section class="lt" id="preguntas" aria-labelledby="preg-t"><div class="w">
<p class="ey">Preguntas</p><h2 id="preg-t">Lo que <em>conviene saber</em></h2>
<p class="sec-p">Respuestas cortas y un glosario del comprador. Información general de octubre de 2026: no es una condición ni una promesa de ${esc(NAME)}.</p>
<div class="qa" data-qa><div class="qa-tabs" role="tablist" aria-label="Preguntas y glosario" hidden><button type="button" role="tab" id="qa-t1" aria-controls="qa-p1" aria-selected="true">Preguntas frecuentes</button><button type="button" role="tab" id="qa-t2" aria-controls="qa-p2" aria-selected="false" tabindex="-1">Glosario del comprador</button></div>
<div class="qa-p" id="qa-p1" role="tabpanel" aria-labelledby="qa-t1"><h3>Preguntas frecuentes</h3>${faq}</div><div class="qa-p" id="qa-p2" role="tabpanel" aria-labelledby="qa-t2"><h3>Glosario del comprador</h3>${glos}</div></div>
</div></section>`;
const semana = H.semana || [];
const closedDays = [0, 1, 2, 3, 4, 5, 6].filter((d) => !semana.some((g) => g.dias.includes(d)));
const morningOnly = semana.filter((g) => g.rangos.length === 1).flatMap((g) => g.dias);
const DOW = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const openSpec = semana.flatMap((g) => g.rangos.map((r) => ({ '@type': 'OpeningHoursSpecification', dayOfWeek: g.dias.map((x) => DOW[x]), opens: r[0], closes: r[1] })));

// ---- secciones nuevas: comparador, cómo comprar, tu usado, búsqueda, guía, visita, mapa ----
const COORD = L.coordenadas;
const CVI = {
  wa: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 3.2a8.7 8.7 0 0 0-7.4 13.2L3.4 20.8l4.5-1.2A8.7 8.7 0 1 0 12 3.2z"/><path d="M8.9 8.6c.2-.4.4-.4.7-.4h.5c.2 0 .4 0 .6.5l.7 1.6c.1.2 0 .4-.1.6l-.5.6c-.1.2-.2.3 0 .6.4.7 1.4 1.8 2.6 2.3.3.1.5.1.6-.1l.7-.8c.2-.2.4-.2.6-.1l1.6.8c.2.1.3.2.3.4 0 .5-.2 1.2-.8 1.6-.6.4-1.4.5-2.4.2-1.6-.5-3-1.6-4-3-.7-1-1.3-2.2-1-3.3.1-.4.3-.8.7-1.1z"/></svg>',
  copy: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="9" y="9" width="11" height="11" rx="1.5"/><path d="M5 15V5.5A1.5 1.5 0 0 1 6.5 4H15"/></svg>',
  spark: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18"/></svg>',
  clear: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 7h14M10 7V4.5h4V7M7 7l1 13h8l1-13"/></svg>',
  km: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 17a8 8 0 1 1 16 0M12 17l4-5M7 17h2M15 17h2"/></svg>',
};
const cvSun = '<div class="cv-sun" data-sun aria-hidden="true"><svg viewBox="0 0 96 54" focusable="false"><defs><clipPath id="cvc-ID"><rect x="0" y="0" width="96" height="40"/></clipPath></defs><g class="cv-rays"><path d="M48 3v7M22 12l5 5M74 12l-5 5M9 27h7M80 27h7"/></g><g clip-path="url(#cvc-ID)"><circle class="cv-orb" cx="48" cy="40" r="17"/></g><path class="cv-hz" d="M4 40h88"/><path class="cv-hz2" d="M18 47h60M30 53h36"/></svg></div>';
const cvChips = (id, lbl, opts, multi) => `<div class="cv-chips" role="group" aria-label="${esc(lbl)}" data-chips${multi ? ' data-multi' : ''} data-target="${id}">${opts.map((o) => `<button type="button" class="cv-chip" aria-pressed="false" data-v="${esc(o)}">${esc(o)}</button>`).join('')}</div><input type="hidden" id="${id}" data-lbl="${esc(lbl)}" data-p>`;
const cvL = (txt, forId, hint) => `<label class="cv-l"${forId ? ` for="${forId}"` : ''}>${txt}${hint ? `<small>${hint}</small>` : ''}</label>`;
const cvT = (txt, hint) => `<span class="cv-l" role="presentation">${txt}${hint ? `<small>${hint}</small>` : ''}</span>`;
const cvForm = ({ uid, intro, aria, ey, h3, body, nota, extra = '', busca = false, ejemplo }) => `
<form class="cv-form${busca ? ' cv-form--busca' : ''}" data-msg${busca ? ' data-busca' : ''} data-intro="${esc(intro)}" aria-label="${esc(aria)}">
<header class="cv-head">${cvSun.replace(/ID/g, uid)}<div class="cv-ht"><p class="cv-ey">${ey}</p><h3>${h3}</h3></div><div class="cv-prog" aria-live="polite"><span class="cv-prog-t" data-prog-t>Sin datos todavía</span><span class="cv-prog-b" aria-hidden="true"><i data-prog-b></i></span></div></header>
<div class="cv-grid">${body}</div>
${extra}
<div class="cv-bub" data-burbuja><p class="cv-bub-h"><span>Así llega tu mensaje</span><em>Se arma solo</em></p><div class="cv-bub-b" data-bub-b></div></div>
<textarea class="msg-v cv-msgv" readonly hidden aria-label="Mensaje armado"></textarea>
<div class="cv-acts">${C.whatsApp ? `<a class="cv-btn cv-btn--wa" data-wa-msg data-wa="${C.whatsApp}" href="https://wa.me/${C.whatsApp}" ${EXT}>${CVI.wa}<span>Enviar por WhatsApp</span></a>` : ''}
<div class="cv-tools"><button class="cv-btn cv-btn--g${C.whatsApp ? '' : ' cv-btn--main'}" type="submit" data-copiar-msg hidden>${CVI.copy}<span>Copiar mensaje</span></button><button class="cv-btn cv-btn--g" type="button" data-ejemplo="${esc(JSON.stringify(ejemplo))}" hidden>${CVI.spark}<span>Completar con un ejemplo</span></button><button class="cv-btn cv-btn--g" type="button" data-limpiar hidden>${CVI.clear}<span>Limpiar</span></button></div>
<p class="cv-soc">También podés escribirle a la agencia por <a href="${FB}" ${EXT}>Facebook</a> o <a href="${IG}" ${EXT}>Instagram</a>.</p></div>
<p class="msg-s" role="status" aria-live="polite"></p>
</form>
<p class="src conversion-note cv-note">${nota}</p>`;

const secUsado = hasSvc('permuta') ? `
<section class="conversion conversion--trade" id="tu-usado" aria-labelledby="usado-t"><div class="w">
<div class="conversion-layout">
<div class="conversion-story">
<p class="ey">Tu próximo paso</p><h2 id="usado-t">Entregá tu usado como <em>parte de pago</em></h2>
<p class="sec-p">${hasSvc('tasacion') ? 'Recibimos vehículos usados como parte de pago y la tasación es sin cargo, según informa ' + esc(GNAME) + '. ' : 'Recibimos vehículos usados como parte de pago, según informa ' + esc(GNAME) + '. '}Contanos cuál es y armá el mensaje para enviárselo a la agencia.</p>
<ol class="cv-steps"><li><b>Contanos qué tenés</b><span>Marca, modelo, año y kilometraje alcanzan para empezar.</span></li><li><b>Mirá tu mensaje armarse</b><span>Se escribe solo a medida que completás los datos.</span></li><li><b>Envialo a la agencia</b><span>Por WhatsApp. Las condiciones se acuerdan con ellos.</span></li></ol>
<ul class="cv-pills"><li>Parte de pago</li>${hasSvc('tasacion') ? '<li>Tasación sin cargo</li>' : ''}<li>Autos y motos</li></ul>
</div>
<div class="conversion-panel cv-panel">
${cvForm({
  uid: 'u', intro: 'Hola! Quiero consultar por entregar mi usado como parte de pago.', aria: 'Datos de tu usado', ey: 'Empezá por acá', h3: 'Datos de tu usado',
  ejemplo: { 'u-mm': 'Chevrolet Corsa Classic 1.4', 'u-an': '2014', 'u-km': '118.000', 'u-co': 'Nafta', 'u-tr': 'Manual', 'u-es': 'Papeles al día, Services al día', 'u-in': 'Que me lo tasen', 'u-no': 'Lo puedo llevar a la agencia cuando quieran verlo.' },
  body: `
<div class="cv-f cv-f--wide">${cvL('Marca y modelo', 'u-mm')}<input id="u-mm" data-lbl="Marca y modelo" data-p list="dl-marcas" autocomplete="off" placeholder="Ej: Chevrolet Corsa Classic 1.4" required></div>
<div class="cv-f">${cvL('Año', 'u-an')}<input id="u-an" data-lbl="Año" data-p data-anio inputmode="numeric" maxlength="4" autocomplete="off" placeholder="Ej: 2014"></div>
<div class="cv-f">${cvL('Kilometraje', 'u-km')}<span class="cv-sfx" data-sfx="km"><input id="u-km" data-lbl="Kilometraje" data-p data-fmt="miles" inputmode="numeric" autocomplete="off" placeholder="Ej: 120.000"></span></div>
<div class="cv-f">${cvT('Combustible')}${cvChips('u-co', 'Combustible', ['Nafta', 'Diésel', 'GNC', 'Otro'])}</div>
<div class="cv-f">${cvT('Caja')}${cvChips('u-tr', 'Caja', ['Manual', 'Automática'])}</div>
<div class="cv-f cv-f--wide">${cvT('Cómo está', 'Podés marcar varias')}${cvChips('u-es', 'Estado', ['Papeles al día', 'Services al día', 'Un solo dueño', 'Sin choques importantes', 'Con GNC'], true)}</div>
<div class="cv-f cv-f--wide">${cvT('Qué querés hacer')}${cvChips('u-in', 'Quiero', ['Que me lo tasen', 'Entregarlo y llevarme otro'])}</div>
<div class="cv-f cv-f--wide">${cvL('¿Alguna unidad te interesa?', 'u-un', 'Opcional')}<select id="u-un" data-lbl="Unidad que me interesa" data-stock><option value="">Todavía no sé</option></select></div>
<div class="cv-f cv-f--wide">${cvL('Algo más que quieras contar', 'u-no', 'Opcional')}<textarea id="u-no" data-lbl="Comentarios" maxlength="280" placeholder="Ej: tiene GNC de quinta generación, cubiertas nuevas…"></textarea><span class="cv-cnt" data-cnt aria-hidden="true">0 / 280</span></div>`,
  nota: 'Es un mensaje que armás vos: no se envía ni se guarda nada desde este sitio. La tasación y las condiciones se acuerdan con la agencia.',
})}
</div>
</div>
</div></section>` : '';

const MARCAS = [...new Set([...A.autos.map((a) => a.marca), 'Chevrolet', 'Volkswagen', 'Peugeot', 'Renault', 'Ford', 'Fiat', 'Toyota', 'Citroën', 'Honda', 'Nissan', 'Hyundai', 'Kia', 'Jeep', 'Audi', 'BMW', 'Mercedes-Benz', 'Suzuki', 'Yamaha'])].sort((x, y) => x.localeCompare(y, 'es'));

const secBusqueda = `
<section class="conversion conversion--search lt" id="busqueda" aria-labelledby="bus-t"><div class="w">
<div class="conversion-layout">
<div class="conversion-story">
<p class="ey">Del otro lado del volante</p><h2 id="bus-t">Contanos qué auto <em>buscás</em></h2>
<p class="sec-p">Armá un mensaje con lo que tenés en mente y enviáselo a la agencia por el canal que prefieras.</p>
<ol class="cv-steps"><li><b>Decinos qué buscás</b><span>Una marca o un modelo alcanza; el resto afina la búsqueda.</span></li><li><b>Mirá qué hay publicado</b><span>Mientras escribís, te mostramos las unidades del catálogo que encajan.</span></li><li><b>Enviá la consulta</b><span>Por WhatsApp, sin registrarte ni dejar datos en el sitio.</span></li></ol>
<ul class="cv-pills"><li>Sin compromiso</li><li>Financiación</li><li>Tu usado como parte de pago</li></ul>
</div>
<div class="conversion-panel cv-panel">
<datalist id="dl-marcas">${MARCAS.map((m) => `<option value="${esc(m)}">`).join('')}</datalist>
${cvForm({
  uid: 'b', busca: true, intro: 'Hola! Estoy buscando un auto.', aria: 'Qué auto buscás', ey: 'Armá tu consulta', h3: 'El auto que tenés en mente',
  ejemplo: { 'b-mm': 'Volkswagen Amarok', 'b-ca': 'Pick-up', 'b-an': '2010', 'b-tr': 'Manual', 'b-co': 'Diésel', 'b-mo': 'US$', 'b-pr': '25.000', 'b-us': 'Trabajo, Ruta', 'b-pa': 'Financiado', 'b-no': 'Me interesa que sea 4x4.' },
  body: `
<div class="cv-f cv-f--wide">${cvL('Marca o modelo', 'b-mm')}<input id="b-mm" data-lbl="Marca o modelo" data-p list="dl-marcas" autocomplete="off" placeholder="Ej: Peugeot 208, Chevrolet Cruze…" required></div>
<div class="cv-f cv-f--wide">${cvT('Tipo de vehículo', 'Podés marcar varios')}${cvChips('b-ca', 'Carrocería', ['Sedán', 'Hatchback', 'Pick-up', 'SUV', 'Utilitario', 'Monovolumen'], true)}</div>
<div class="cv-f">${cvL('Año mínimo', 'b-an')}<input id="b-an" data-lbl="Año mínimo" data-p data-anio inputmode="numeric" maxlength="4" autocomplete="off" placeholder="Ej: 2015"><div class="cv-quick" aria-label="Años sugeridos">${[2010, 2015, 2018, 2020].map((y) => `<button type="button" class="cv-q" data-set="b-an" data-v="${y}">${y}+</button>`).join('')}</div></div>
<div class="cv-f">${cvT('Caja', 'Indistinto si no elegís')}${cvChips('b-tr', 'Transmisión', ['Manual', 'Automática'])}${cvT('Combustible', 'Podés marcar varios')}${cvChips('b-co', 'Combustible', ['Nafta', 'Diésel', 'GNC', 'Híbrido'], true)}</div>
<div class="cv-f cv-f--wide cv-money">${cvL('Presupuesto aproximado', 'b-pr', 'Opcional')}<div class="cv-money-r"><div class="cv-cur" role="group" aria-label="Moneda"><button type="button" class="cv-chip is-on" aria-pressed="true" data-cur="$">$</button><button type="button" class="cv-chip" aria-pressed="false" data-cur="US$">US$</button></div><input id="b-pr" data-lbl="Presupuesto" data-p data-fmt="miles" data-pre="#b-mo" inputmode="numeric" autocomplete="off" placeholder="Ej: 12.000.000"><input type="hidden" id="b-mo" value="$"></div></div>
<div class="cv-f cv-f--wide">${cvT('Para qué lo vas a usar', 'Podés marcar varios')}${cvChips('b-us', 'Uso', ['Trabajo', 'Familia', 'Ciudad', 'Ruta', 'Primer auto'], true)}</div>
<div class="cv-f cv-f--wide">${cvT('Cómo pensás pagarlo', 'Podés marcar varios')}${cvChips('b-pa', 'Forma de pago', ['Contado', 'Financiado', 'Con mi usado'], true)}</div>
<div class="cv-f cv-f--wide">${cvL('Algo más que quieras contar', 'b-no', 'Opcional')}<textarea id="b-no" data-lbl="Comentarios" maxlength="280" placeholder="Ej: busco algo económico en consumo y con aire acondicionado…"></textarea><span class="cv-cnt" data-cnt aria-hidden="true">0 / 280</span></div>`,
  extra: '<div class="cv-match" data-match aria-live="polite"><p class="cv-match-h" data-match-h>Escribí una marca o modelo para ver qué hay publicado</p><ul class="cv-match-l" data-match-l></ul></div>',
  nota: 'Es un mensaje que armás vos: no se envía ni se guarda nada desde este sitio. No confirma disponibilidad ni precios.',
})}
</div>
</div>
</div></section>`;

const secGuia = `
<section id="guia" aria-labelledby="guia-t"><div class="w">
<p class="ey">Guía</p><h2 id="guia-t">Antes de comprar un <em>usado</em></h2>
<p class="sec-p">Información general para cualquier compra de un usado, de octubre de 2026. No es una condición ni una promesa de ${esc(NAME)}.</p>
<div class="guia-bar"><button class="btn sm" type="button" data-guia-all hidden>Plegar todo</button></div>
<div class="guia">
<details class="gd"><summary><h3>Qué mirar en el auto</h3><span class="gd-c">6 puntos</span></summary><div class="gd-b"><ul><li>Carrocería y pintura: diferencias de tono, juntas desparejas o signos de golpes.</li><li>Neumáticos, frenos y suspensión: desgaste parejo y ruidos al probarlo.</li><li>Motor y debajo del auto: fugas de aceite o líquidos.</li><li>Tablero y luces: que no queden testigos encendidos.</li><li>Kilometraje: que sea coherente con el desgaste de pedales, volante y asientos.</li><li>Probalo en marcha, en calle y en ruta si podés.</li></ul></div></details>
<details class="gd"><summary><h3>Papeles que conviene pedir</h3><span class="gd-c">5 puntos</span></summary><div class="gd-b"><ul><li>Título y cédula del automotor, y que los datos coincidan con el auto (dominio, motor y chasis).</li><li>Informe de dominio del Registro del Automotor.</li><li>Libre deuda de patentes y de multas.</li><li>Verificación policial vigente.</li><li>Formulario 08 de transferencia, firmado por quien vende.</li></ul></div></details>
<details class="gd"><summary><h3>Qué preguntarle a quien vende</h3><span class="gd-c">6 puntos</span></summary><div class="gd-b"><ul><li>¿Cuántos dueños tuvo y desde cuándo está a nombre de quien lo vende?</li><li>¿Hay facturas o registro de los services y reparaciones?</li><li>¿Tuvo choques o reparaciones importantes?</li><li>¿Pesa alguna prenda, embargo o restricción sobre el dominio?</li><li>¿Podés hacerlo revisar por un mecánico de tu confianza antes de decidir?</li><li>Dejá por escrito lo acordado: precio, forma de pago y fecha de entrega.</li></ul></div></details>
</div>
<p class="src">Los requisitos y costos de la transferencia cambian: consultalos en el Registro del Automotor o con un gestor o escribano antes de pagar.</p>
</div></section>`;

const mapa = COORD ? `
<div class="map" id="mapa" data-lat="${COORD.lat}" data-lng="${COORD.lng}" data-leaflet="js/vendor/leaflet.js" data-css="js/vendor/leaflet.css">
<div class="map-p"><p>Mapa interactivo de OpenStreetMap. Se carga solo si lo pedís.</p><button class="btn" type="button" data-mapa-abrir hidden>Ver mapa</button><p class="map-m src" role="status" aria-live="polite"></p></div>
<div class="map-v" role="region" aria-label="Mapa con la ubicación" hidden></div>
<div class="row"><a class="btn" href="${L.mapsUrl}" ${EXT}>Abrir en Google Maps</a><a class="btn" href="https://waze.com/ul?ll=${COORD.lat},${COORD.lng}&amp;navigate=yes" ${EXT}>Abrir en Waze</a><button class="btn" type="button" data-copiar="${esc(L.address)}, ${esc(L.city)}, ${esc(L.province)}" hidden>Copiar dirección</button></div>
<p class="src">Ubicación según la ficha de Google Maps. La dirección es ${esc(L.address)}, ${esc(L.city)}.</p>
</div>` : '';


// ---- horarios + mapa (sección debajo del hero), contacto y sucursales con mapa ----
const gmapsEmbed = (q) => `https://maps.google.com/maps?q=${encodeURIComponent(q)}&hl=es&z=16&output=embed`;
const gmapsSearch = (q) => `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(q)}`;
const DIR_COMPLETA = `${L.address}, ${L.city}, ${L.province}`;
const ICX = {
  pin: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>',
  sun: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 17h16M7 17a5 5 0 0 1 10 0M12 6v2.5M5.6 9.6l1.8 1.8M18.4 9.6l-1.8 1.8"/></svg>',
};
const ICN = {
  route: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6" cy="18" r="2.2"/><circle cx="18" cy="6" r="2.2"/><path d="M8 18h6.5a3 3 0 0 0 0-6h-5a3 3 0 0 1 0-6H16"/></svg>',
  car: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 15.5v-3l2-5h13l2 5v3M3.5 15.5h17M3.5 15.5v2.5M20.5 15.5v2.5"/><circle cx="7.5" cy="14" r=".6"/><circle cx="16.5" cy="14" r=".6"/></svg>',
  coin: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M14.8 9.2c-.6-.8-1.6-1.2-2.8-1.2-1.6 0-2.7.8-2.7 2s1 1.7 2.7 2c1.7.3 2.7.8 2.7 2s-1.1 2-2.7 2c-1.2 0-2.2-.4-2.8-1.2M12 6.5V8M12 16v1.5"/></svg>',
  swap: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 9h13l-3.5-3.5M19 15H6l3.5 3.5"/></svg>',
  shield: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.5 5 6v5.5c0 4.2 2.8 7.4 7 9 4.2-1.6 7-4.8 7-9V6z"/><path d="m9 12 2.2 2.2L15.5 10"/></svg>',
  group: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="6" r="2.5"/><circle cx="5.5" cy="17.5" r="2.5"/><circle cx="18.5" cy="17.5" r="2.5"/><path d="M12 8.5v3.5M12 12 6.5 15.2M12 12l5.5 3.2"/></svg>',
};
const hrFilas = H.display ? H.semana.map((g) => `<tr data-dias="${g.dias.join(',')}"><th scope="row"><span class="hz-dn">${esc(g.etiqueta)}</span><span class="hz-hoy">Hoy</span></th><td>${g.rangos.map((r) => `<span class="hz-rg">${fh(r[0])} a ${fh(r[1])}</span>`).join('')}</td></tr>`).join('') + (H.domingo ? `<tr data-dias="0"><th scope="row"><span class="hz-dn">Domingos</span><span class="hz-hoy">Hoy</span></th><td><span class="hz-rg hz-rg--x">${esc(H.domingo)}</span></td></tr>` : '') : '';
const mapaHr = COORD ? `<div class="hz-map" id="mapa" data-lat="${COORD.lat}" data-lng="${COORD.lng}" data-nombre="${esc(NAME)}" data-dir="${esc(DIR_COMPLETA)}" data-gmaps="${esc(L.mapsUrl)}" data-leaflet="js/vendor/leaflet.js" data-css="js/vendor/leaflet.css">
<div class="hz-map-v" role="region" aria-label="Mapa con la ubicación de ${esc(NAME)}"></div>
<div class="hz-map-ph" data-mapa-ph><span class="hz-map-ic">${ICX.pin}</span><p>Mapa de ${esc(L.city)}</p><div class="row"><button class="btn p sm" type="button" data-mapa-abrir hidden>Ver mapa</button><a class="btn sm" href="${L.mapsUrl}" ${EXT}>Abrir en Google Maps</a></div><p class="map-m src" role="status" aria-live="polite"></p></div>
</div>` : '';
const hrAddr = H.display ? `<div class="hz-addr"><div class="hz-addr-t"><span class="hz-addr-i">${ICX.pin}</span><div><p class="hz-k">Dónde estamos</p><p class="hz-a">${esc(DIR_COMPLETA)}</p>${L.direccionAnterior ? `<p class="hz-ant">Antes: ${esc(L.direccionAnterior)}</p>` : ''}</div></div>
<div class="row"><a class="btn p sm" href="${L.mapsUrl}" ${EXT}>Cómo llegar</a>${COORD ? `<a class="btn sm" href="https://waze.com/ul?ll=${COORD.lat},${COORD.lng}&amp;navigate=yes" ${EXT}>Abrir en Waze</a>` : ''}<button class="btn sm" type="button" data-copiar="${esc(DIR_COMPLETA)}" hidden>Copiar dirección</button></div></div>` : '';
const secHorarios = H.display ? `
<section id="horarios" class="hz-hr hz-lux hz-v71" aria-labelledby="hor-t" data-semana="${esc(JSON.stringify(H.semana))}"><div class="w">
<div class="hz-hr-head"><p class="ey">Horarios y ubicación</p><h2 id="hor-t">Cuándo y dónde <em>visitarnos</em></h2></div>
<div class="hz-stage">
<div class="hz-panel">
<div class="hz-now" data-live data-abierto="0">
<p class="hz-now-st"><span class="hz-dot" aria-hidden="true"></span><span data-estado-t>Horario de atención</span></p>
<p class="hz-now-lbl" data-cd-lbl></p>
<div class="hz-cd" role="timer" aria-label="Tiempo que falta"><span class="hz-cd-u"><b data-cd-h>--</b><i>horas</i></span><span class="hz-cd-u"><b data-cd-m>--</b><i>minutos</i></span><span class="hz-cd-u"><b data-cd-s>--</b><i>segundos</i></span></div>
<p class="hz-now-d" data-estado-d>${esc(H.corto)}</p>
</div>
<div class="hz-wk"><p class="hz-wk-t">Días y horarios de atención</p>
<table class="hz-tbl"><caption class="sr">Horario de atención</caption><tbody>${hrFilas}</tbody></table></div>
<p class="hz-tz">Hora de Argentina: ahora son las <b data-reloj>--:--:--</b></p>
</div>
<div class="hz-mapwrap">
${mapaHr}
${hrAddr}
</div>
</div>
<p class="src hz-src">Ubicación según la ficha de Google Maps. Horario según el sitio del ${esc(GNAME)}; puede variar, confirmalo antes de ir.</p>
</div></section>` : '';

const visHr = H.display ? `<ul class="vz-hrs">${H.semana.map((g) => `<li data-dias="${g.dias.join(',')}"><span>${esc(g.etiqueta)}</span><b>${g.rangos.map((r) => `${fh(r[0])} a ${fh(r[1])}`).join(' y ')}</b></li>`).join('')}${H.domingo ? `<li data-dias="0"><span>Domingos</span><b>${esc(H.domingo)}</b></li>` : ''}</ul>` : '';
const secVisita = `
<section id="visita" class="visita-s vz" aria-labelledby="vis-t"><div class="w vis-w">
<div class="vz-head"><p class="ey">Visita</p><h2 id="vis-t">Coordiná tu <em>visita</em></h2>
<p class="sec-p">Pasá a conocer las unidades. Armá la consulta en un minuto y la agencia acuerda con vos el día y la hora.</p></div>
<div class="vz-grid">
<div class="vz-main"><h3>Agendá una visita y prueba de manejo</h3>
<ol class="vz-steps"><li><b>Elegí día y franja</b><span>En la página de reserva, desde el celular o la computadora.</span></li><li><b>Se arma tu consulta</b><span>Queda lista para enviarla a la agencia por WhatsApp.</span></li><li><b>La agencia te confirma</b><span>Es una consulta, no un turno: el día y la hora se acuerdan con la agencia.</span></li></ol>
<div class="vz-cta"><a class="btn p vz-go" href="reserva.html">Agendar visita</a>${C.whatsApp ? `<a class="btn" href="${wa('Hola! Quiero coordinar una visita y prueba de manejo.')}" ${EXT}>WhatsApp</a>` : ''}<a class="btn" href="${L.mapsUrl}" ${EXT}>Cómo llegar</a>${C.phoneTel ? `<a class="btn" href="tel:${C.phoneTel}">Llamar</a>` : ''}</div></div>
${H.display ? `<aside class="vz-side" aria-label="Antes de venir"><p class="vz-side-k">Antes de venir</p>
<div class="vz-live" data-live data-abierto="0"><span class="hz-dot" aria-hidden="true"></span><div><p class="vz-live-t" data-estado-t>Horario de atención</p><p class="vz-live-c" data-cd-full></p></div></div>
${visHr}
<p class="vz-addr">${ICX.pin}<span>${esc(DIR_COMPLETA)}</span></p>
<a class="btn sm" href="#horarios">Ver horarios y mapa</a></aside>` : ''}
</div>
</div></section>`;

const chan = (cls, icon, k, v, sub, href, ext) => `<li><a class="hz-chn${cls ? ' ' + cls : ''}" href="${href}"${ext ? ' ' + EXT : ''}><span class="hz-chn-i">${icon}</span><span class="hz-chn-t"><span class="hz-chn-k">${k}</span><span class="hz-chn-v">${v}</span><span class="hz-chn-s">${sub}</span></span></a></li>`;
const canales = [
  C.whatsApp ? chan('hz-chn--p', IC.wa, 'WhatsApp', esc(C.whatsAppDisplay), 'Escribinos y te respondemos', WA, true) : '',
  C.phoneTel ? chan('', IC.tel, 'Teléfono', esc(C.phone), 'Llamanos en horario de atención', `tel:${C.phoneTel}`, false) : '',
  C.email ? chan('', IC.mail, 'Correo', esc(C.email), 'Consultas por escrito', `mailto:${esc(C.email)}`, false) : '',
  chan('', ICX.pin, 'Visitanos', esc(L.address), `${esc(L.city)} · ver horarios y mapa`, '#horarios', false),
].filter(Boolean).join('');
const redes = [
  `<li><a href="${FB}" ${EXT}>Facebook</a></li>`,
  `<li><a href="${IG}" ${EXT}>Instagram @${esc(C.instagram)}</a></li>`,
  D.reviews.googleUrl ? `<li><a href="${D.reviews.googleUrl}" ${EXT}>Ficha de Google</a></li>` : '',
  `<li><a href="${GWEB}" ${EXT}>${esc(GNAME)}</a></li>`,
].filter(Boolean).join('');

const brQ = (x) => `${x.direccion}, ${/Santa Fe$/.test(x.direccion.trim()) ? 'Santa Fe' : 'Entre Ríos'}, Argentina`;
const suc = (D.identity.grupoSucursales || []).filter((x) => !x.esta);
const cityOf = (x) => x.direccion.split(',').pop().trim();
const grupo = suc.length ? `
<div class="hz-grp sb" id="sucursales"><div class="sb-head"><div><p class="sb-k">${suc.length + 1} puntos de atención</p><h3>Sucursales del ${esc(GNAME)}</h3>
<p class="sec-p">Elegí la sucursal que te quede más cerca. Cada tarjeta tiene su mapa, el botón para llegar y cómo contactarla.</p></div>
<ul class="sb-how" aria-label="Cómo usar esta sección"><li>${ICX.pin}<span>Mirá dónde queda</span></li><li>${ICN.route}<span>Tocá «Cómo llegar»</span></li><li>${IC.tel}<span>Llamá o escribí</span></li></ul></div>
<ul class="hz-br-l">${suc.map((x) => `<li class="hz-br"><div class="hz-br-top"><span class="hz-br-pin">${ICX.pin}</span><div><h4>${esc(x.nombre)}</h4><p class="hz-br-city">${esc(cityOf(x))}</p></div></div><div class="hz-br-map"><iframe src="${esc(gmapsEmbed(brQ(x)))}" title="Mapa de ${esc(x.nombre)}: ${esc(x.direccion)}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe></div><div class="hz-br-b"><p class="hz-br-a">${esc(x.direccion)}</p><div class="hz-br-act"><a class="sb-b sb-b--p" href="${esc(gmapsSearch(brQ(x)))}" ${EXT}>${ICN.route}<span>Cómo llegar</span></a>${x.tel ? `<a class="sb-b" href="tel:${x.telTel}">${IC.tel}<span>Llamar<small>${esc(x.tel)}</small></span></a>` : ''}${x.wa ? `<a class="sb-b" href="https://wa.me/${x.waNum}" ${EXT}>${IC.wa}<span>WhatsApp<small>${esc(x.wa)}</small></span></a>` : ''}</div></div></li>`).join('')}</ul>
<p class="src">Fuente: material de contacto del ${esc(GNAME)}. Los números los publica el grupo; algunas sucursales comparten el mismo WhatsApp.</p></div>` : '';

const puntos = D.identity.grupoSucursales || [];
const ciudades = [...new Set(puntos.map(cityOf))];
const secNosotros = `
<section class="nz" id="nosotros" aria-labelledby="nos-t">
<div class="nz-top"><div class="w nz-w">
<div class="nz-intro">
<p class="ey">Nosotros</p>
<span class="nz-logo"><img src="images/logo-sm.png" width="360" height="144" alt=""></span>
<h2 id="nos-t">Quiénes <em>somos</em></h2>
<p class="nz-lead">${esc(NAME)} es un concesionario de ${esc(L.city)} que forma parte del ${esc(GNAME)}.</p>
<p class="nz-p">${esc(D.presentacion.antiguedad)}</p>
<div class="row nz-cta"><a class="btn p" href="#unidades">Ver unidades</a><a class="btn" href="#contacto">Hablar con un asesor</a></div>
</div>
<div class="nz-big"><span class="nz-sun" aria-hidden="true"></span><p class="nz-num">10</p><p class="nz-num-l">años de respaldo</p><p class="nz-num-s">en el mercado regional, según su página de Facebook</p></div>
</div></div>
<div class="nz-stats"><ul>
${autos.length ? `<li><b>${autos.length}</b><span>unidades publicadas en esta web${A.relevadoEl ? `, relevadas el ${esc(fdate(A.relevadoEl))}` : ''}</span></li>` : ''}
<li><b>${puntos.length}</b><span>puntos de atención que lista el ${esc(GNAME)}, uno de ellos en ${esc(L.city)}</span></li>
<li><b>${ciudades.length}</b><span>localidades con atención: ${esc(ciudades.join(', ').replace(/, ([^,]*)$/, ' y $1'))}</span></li>
</ul></div>
<div class="nz-body"><div class="w">
<h3 class="nz-h">Qué podés resolver con nosotros</h3>
<ul class="nz-tiles">
<li class="nz-tile"><span class="nz-ic">${ICN.car}</span><h4>Autos y motos</h4><p>Usados publicados para ${esc(L.city)} y financiación para llevarlos.</p><a href="#unidades">Ver unidades</a></li>
<li class="nz-tile"><span class="nz-ic">${ICN.coin}</span><h4>Financiación</h4><p>Ofrecemos financiación para autos y motos. Los montos y las condiciones dependen de la unidad y de cada solicitante.</p><a href="#financiacion">Ver cómo financiar</a></li>
${hasSvc('permuta') ? `<li class="nz-tile"><span class="nz-ic">${ICN.swap}</span><h4>Tu usado cuenta</h4><p>Se reciben usados como parte de pago${hasSvc('tasacion') ? ' y la tasación es sin cargo' : ''}, según informa ${esc(GNAME)}.</p><a href="#tu-usado">Armar mi consulta</a></li>` : ''}
${hasSvc('garantia') ? `<li class="nz-tile"><span class="nz-ic">${ICN.shield}</span><h4>Revisión y garantía</h4><p>Los usados pasan por revisión técnica y se entregan con garantía, según informa ${esc(GNAME)}. Las condiciones dependen de cada vehículo.</p><a href="#preguntas">Ver preguntas</a></li>` : ''}
<li class="nz-tile"><span class="nz-ic">${ICN.group}</span><h4>Respaldo del grupo</h4><p>Forma parte del ${esc(GNAME)}, con sucursales en Paraná y Santa Fe.</p><a href="#sucursales">Ver sucursales</a></li>
</ul>
<div class="nz-net"><h3 class="nz-h">Dónde encontrarnos</h3><p class="nz-net-p">Estos son los puntos de atención que lista el ${esc(GNAME)}.</p>
<ul>${puntos.map((x) => `<li${x.esta ? ' class="is-here"' : ''}>${ICX.pin}<div><b>${esc(x.nombre)}</b><span>${esc(x.direccion)}</span>${x.esta ? '<em>Estás en esta sucursal web</em>' : ''}</div></li>`).join('')}</ul></div>
</div></div>
</section>`;

const ld = {
  '@context': 'https://schema.org', '@type': 'AutoDealer', name: NAME,
  address: { '@type': 'PostalAddress', streetAddress: L.address, postalCode: L.postalCode, addressLocality: L.city, addressRegion: L.province, addressCountry: 'AR' },
  sameAs: [FB, IG],
  ...(siteUrl ? { url: siteUrl } : {}), ...(C.phoneTel ? { telephone: C.phoneTel } : {}), ...(C.email ? { email: C.email } : {}), ...(L.mapsUrl ? { hasMap: L.mapsUrl } : {}), ...(openSpec.length ? { openingHoursSpecification: openSpec } : {}),
};

const index = page({
  title: `${NAME} · Autos y motos en ${L.city}, ${L.province}`,
  desc: `${NAME} en ${L.city}, ${L.province}: autos y motos con financiación. Visitanos en ${L.address} o mirá las unidades en Facebook e Instagram.`,
  file: 'index.html',
  extraHead: `<script type="application/ld+json">${JSON.stringify(ld)}</script>\n<script defer src="js/secciones.js"></script>\n<script defer src="js/mapa.js"></script>\n<script defer src="js/horarios.js"></script>
<script defer src="js/site.js"></script>\n<script defer src="js/hero-rail.js"></script>\n`,
  body: `${header()}
<main id="top">
<div class="hero" data-hero-carousel role="region" aria-roledescription="carrusel" aria-label="Fotografías de vehículos">
<div class="hero-media" role="group" aria-label="Imágenes del carrusel">
<figure class="hero-slide hero-slide--01 is-active" data-hero-slide role="group" aria-roledescription="diapositiva" aria-label="Fotografía" aria-hidden="false"><img src="images/hero/horizonte-slide-01.webp" width="1440" height="1920" alt="" fetchpriority="high" loading="eager" decoding="async"></figure>
<figure class="hero-slide hero-slide--02" data-hero-slide role="group" aria-roledescription="diapositiva" aria-label="Fotografía" aria-hidden="true"><img src="images/hero/horizonte-slide-02.webp" width="1440" height="1920" alt="" loading="lazy" decoding="async"></figure>
<figure class="hero-slide hero-slide--03" data-hero-slide role="group" aria-roledescription="diapositiva" aria-label="Fotografía" aria-hidden="true"><img src="images/hero/horizonte-slide-03.webp" width="1440" height="1920" alt="" loading="lazy" decoding="async"></figure>
<figure class="hero-slide hero-slide--04" data-hero-slide role="group" aria-roledescription="diapositiva" aria-label="Fotografía" aria-hidden="true"><img src="images/hero/horizonte-slide-04.webp" width="1440" height="1440" alt="" loading="lazy" decoding="async"></figure>
</div>
<div class="hx-copy">
<p class="ey">Horizonte Automotores</p>
<h1><span class="sr">${esc(NAME)}: </span>Autos y motos <em>en ${esc(L.city)}</em></h1>
<p class="lead">Concesionario del ${esc(GNAME)}. Usados multimarca, financiación y tu usado como parte de pago.</p>
<div class="row"><a class="btn p" href="#unidades">Ver unidades</a>${C.whatsApp ? `<a class="btn" href="${WA}" ${EXT}>Escribir por WhatsApp</a>` : ''}<a class="btn lnk" href="${L.mapsUrl}" ${EXT}>Cómo llegar</a></div></div>
<a class="hx-down" href="#unidades">Explorá las unidades</a>
</div>
</div>
${secHorarios}
<section id="unidades" class="inventory-section" aria-labelledby="unidades-t"><div class="w wide">
<div class="inventory-head">
<div class="inventory-title"><p class="ey reveal">Catálogo seleccionado · ${esc(L.city)}</p><h2 id="unidades-t" class="reveal">Nuestras <em>unidades</em></h2><p class="sec-p">Usados multimarca publicados para María Grande, con financiación y la posibilidad de tomar tu usado como parte de pago.</p></div>
<div class="inventory-meta" aria-label="Resumen del catálogo"><span class="inventory-meta-kicker">Horizonte Automotores</span><span>Unidades publicadas en esta web</span><i aria-hidden="true"></i></div>
</div>
<div class="inventory-rule" aria-hidden="true"><span></span><small>María Grande · Entre Ríos</small><span></span></div>
${unidades}
</div></section>

<section class="finance-section" id="financiacion" aria-labelledby="fin-t"><div class="w">
<div class="finance-head"><div><p class="ey">Financiación y servicios</p><h2 id="fin-t">Financiá tu <em>próximo vehículo</em></h2><p class="sec-p">Ofrecemos financiación para autos y motos. Los montos y condiciones dependen de la unidad y de cada solicitante: consultanos por la que te interese.</p></div><aside class="finance-aside"><span>Horizonte Automotores</span><p>Encontrá una forma de avanzar hacia tu próxima unidad.</p></aside></div>
<div class="finance-rule" aria-hidden="true"><span></span><small>Servicios para moverte mejor</small><span></span></div>
<div class="cards finance-cards"><div class="card finance-card"><span class="finance-card-no">Financiación</span><h3>Créditos Más Autos</h3><p>Figuramos en el listado de concesionarias adheridas a Créditos Más Autos del Banco de la Nación Argentina (listado de ${esc(BNAFECHA)}). <a href="${BNA}" ${EXT}>Ver el listado</a>.</p></div>${hasSvc('permuta') || hasSvc('tasacion') ? `<div class="card finance-card"><span class="finance-card-no">Tu usado</span><h3>Tu usado, parte de pago</h3><p>${[hasSvc('permuta') ? 'Recibimos vehículos usados como parte de pago.' : '', hasSvc('tasacion') ? 'La tasación es sin cargo.' : ''].filter(Boolean).join(' ')}</p></div>` : ''}${hasSvc('garantia') ? `<div class="card finance-card"><span class="finance-card-no">Respaldo</span><h3>Revisión técnica y garantía</h3><p>Los usados pasan por revisión técnica antes de publicarse y se entregan con garantía. Las condiciones dependen de cada vehículo.</p></div>` : ''}</div>
<div class="row fin-cta"><a class="btn p" href="${wa('Hola! Quiero consultar un plan a medida.') || FB}" ${EXT}>${C.whatsApp ? 'Consultar un plan a medida' : 'Consultar por Facebook'}</a><a class="btn" href="#tu-usado">Solicitar tasación personalizada</a></div>
<p class="src">Servicios según lo informado por ${esc(GNAME)} en <a href="${GWEB}" ${EXT}>su sitio</a>.</p>
</div></section>

${secUsado}
${secBusqueda}
${secGuia}
${secPreguntas}
${secVisita}

${secNosotros}

<section id="contacto" class="ct hz-ct" aria-labelledby="contacto-t"><div class="w">
<div class="hz-ct-head"><p class="ey">Contacto</p><h2 id="contacto-t">Hablá con <em>un asesor</em></h2><p class="sec-p">Escribinos o llamanos y te contamos disponibilidad, precio y formas de pago de la unidad que te interese.</p></div>
<div class="hz-ct-grid">
<ul class="hz-ch">${canales}</ul>
<aside class="hz-ct-side" aria-label="Consultar y redes"><p class="hz-ct-t">¿Buscás un auto o una moto?</p><p>Contanos qué estás buscando y te ayudamos a encontrarlo.</p><div class="row"><a class="btn p" href="${ctaHead.href}" ${EXT}>${WA ? 'Consultar con un asesor' : 'Consultar por Facebook'}</a><a class="btn" href="reserva.html">Agendar visita</a></div>
<div class="hz-soc"><p class="hz-k">En la web</p><ul>${redes}</ul></div></aside>
</div>
${grupo}
</div></section>
</main>
${footer(true)}
${C.whatsApp ? `<nav class="cta-bar" aria-label="Acciones rápidas"><a href="${WA}" ${EXT}>Consultar</a><a href="reserva.html">Agendar visita</a></nav>` : `<nav class="cta-bar" aria-label="Acciones rápidas"><a href="${FB}" ${EXT}>Consultar</a><a href="reserva.html">Agendar visita</a></nav>`}
`,
});

const privacidad = page({
  title: `Privacidad y avisos · ${NAME}`,
  desc: `Política de privacidad preliminar y avisos de ${NAME}.`,
  file: 'privacidad.html',
  body: `${header('./', '#top')}
<main id="top"><section><div class="w doc">
<p class="ey">Avisos</p><h1>Privacidad y <em>avisos</em></h1>
<h2>Datos personales</h2>
<p>Este sitio no tiene cuentas ni cookies propias y no guarda datos de quienes lo visitan. Los formularios «Tu usado» y «Contanos qué auto buscás» solo arman un mensaje en tu navegador, que podés copiar y enviar vos: no se transmite nada a este sitio. El mapa de «Horarios y ubicación» trae mosaicos de OpenStreetMap y los mapas de las sucursales del grupo se cargan desde Google Maps al llegar a esa parte de la página; ambos reciben tu dirección IP como cualquier sitio que se visita. Los botones de contacto abren Facebook, Instagram, el sitio de ${esc(GNAME)}${C.whatsApp ? ', WhatsApp' : ''} o Google Maps, que tienen sus propias políticas de privacidad.</p>
<h2>Información de las unidades</h2>
<p>Los datos de las unidades (año, kilometraje, precio, disponibilidad) provienen de las publicaciones de la agencia y del catálogo público de ${esc(GNAME)}, y pueden haber cambiado. Confirmá siempre con ${esc(NAME)} antes de decidir.</p>
<h2>Documento preliminar</h2>
<p>Este texto es preliminar y debe revisarse profesionalmente antes de la publicación definitiva.</p>
<p><a class="btn sm" href="./">Volver al inicio</a></p>
</div></section></main>
${footer(false)}`,
});

const home404 = siteUrl || './';
const logo404 = 'images/logo-sm.png';
const FONTS_404 = FONTS.replace(/url\(fonts\/([^)]+)\)/g, '__U__$1__E__');
const nf404Head = siteUrl
  ? `<style>${FONTS.replace(/url\(fonts\//g, `url(${siteUrl}fonts/`)}</style>\n`
  : '<script>(function(){var s=location.pathname.split("/").filter(Boolean),b=/github\\.io$/.test(location.hostname)&&s.length?"/"+s[0]+"/":"/";var st=document.createElement("style");st.textContent=' + JSON.stringify(FONTS_404) + '.split("__U__").join("ur"+"l("+b+"fonts/").split("__E__").join(")");document.head.appendChild(st);document.addEventListener("DOMContentLoaded",function(){document.getElementById("home").href=b})})()</script>\n';
const nf = page({
  title: `Página no encontrada · ${NAME}`,
  desc: `La página que buscás no existe. Volvé al inicio de ${NAME}.`,
  file: '404.html', withFonts: false,
  extraHead: nf404Head,
  body: `<main class="nf"><div><img class="lg-404" src="${logo404}" width="360" height="144" alt="${esc(NAME)}"><p class="ey">Error 404</p><h1>No encontramos <em>esa página</em></h1><p>Puede que el enlace esté mal escrito o que la página ya no exista.</p><a id="home" class="btn p" href="${home404}">Volver al inicio</a></div></main>`,
});


// ---- reserva.html: consulta de visita (ver docs/RESERVA.md). El número de WhatsApp viaja en data-wa, no en js/reserva.js ----
const reservaBtn = C.whatsApp
  ? `<a id="whatsapp" class="primary" href="https://wa.me/${C.whatsApp}" data-wa="${C.whatsApp}" ${EXT}>Escribir por WhatsApp <span>↗</span></a>`
  : `<button id="whatsapp" class="primary" type="button" data-wa="">Copiar consulta <span>↗</span></button>`;
const reserva = `<!DOCTYPE html>
<html lang="es-AR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
${robotsMeta}<title>Coordiná tu visita · ${esc(NAME)}</title>
<meta name="description" content="Elegí un día y una franja y armá la consulta para ir a ver un auto. Es una consulta, no un turno.">
<meta name="theme-color" content="#0a1012">
<meta property="og:type" content="website">
<meta property="og:title" content="Coordiná tu visita · ${esc(NAME)}">
<meta property="og:locale" content="es_AR">
${OG}${canon('reserva.html')}<link rel="manifest" href="site.webmanifest">
<link rel="icon" type="image/png" sizes="192x192" href="images/icon-192.png">
<link rel="apple-touch-icon" href="images/icon-180.png">
<link rel="stylesheet" href="css/reserva.css"><link rel="stylesheet" href="css/motion.css">
</head>
<body>
<main id="booking" data-step="month" data-closed="${closedDays.join(',')}" data-morning-only="${morningOnly.join(',')}">
  <header class="booking-nav">
    <a class="brand" href="index.html" aria-label="Volver a ${esc(NAME)}"><img class="lg-bk" src="images/logo-sm.png" width="360" height="144" alt="${esc(NAME)}"></a>
    <p class="eyebrow">Coordiná tu visita <span aria-hidden="true">/</span> consulta</p>
    <button class="back" id="back" type="button" aria-label="Volver" hidden>← Atrás</button>
  </header>

  <section class="scene scene--month" aria-labelledby="month-title">
    <div class="scene__meta"><span id="month-status" aria-live="polite"></span></div>
    <div class="month-copy"><p class="kicker">${esc(NAME)}</p><h1 id="month-title">Elegí<em>cuándo</em><em>venir.</em></h1><p class="intro">Elegí un día en el calendario y armá la consulta. Todavía no es un turno.</p></div>
    <div class="calendar-shell">
      <div class="calendar-head"><button id="prev-month" type="button" aria-label="Mes anterior">←</button><h2 id="month-label"></h2><button id="next-month" type="button" aria-label="Mes siguiente">→</button></div>
      <div class="weekday" aria-hidden="true"><span>LU</span><span>MA</span><span>MI</span><span>JU</span><span>VI</span><span>SA</span><span>DO</span></div>
      <div id="calendar" class="calendar" role="group" aria-label="Calendario de consulta"></div>
    </div>
  </section>

  <section class="scene scene--day" aria-labelledby="day-title" hidden>
    <div class="scene__meta"><span id="day-status" aria-live="polite"></span></div>
    <div class="giant-day" aria-hidden="true"><small id="day-month">—</small><span id="day-number">—</span><strong id="day-weekday">—</strong></div>
    <div class="day-copy"><p class="kicker">Tu visita</p><h2 id="day-title">¿Qué día<br><em>te queda bien?</em></h2><p>Elegí el día y se arma el mensaje de consulta.</p></div>
    <button class="next-step" id="to-time" type="button" disabled>Elegir franja <span>→</span></button>
  </section>

  <section class="scene scene--time" aria-labelledby="time-title" hidden>
    <div class="scene__meta"><span id="time-status" aria-live="polite"></span></div>
    <div class="time-copy"><p class="kicker">Franja del día</p><h2 id="time-title">¿Mañana<br><em>o tarde?</em></h2><p>La hora exacta se acuerda con el negocio.</p></div>
    <div id="slots" class="slots" role="listbox" aria-label="Franja del día"></div>
    <button class="next-step" id="to-confirm" type="button" disabled>Ver resumen <span>→</span></button>
  </section>

  <section class="scene scene--confirm" aria-labelledby="confirm-title" hidden>
    <div class="diagonal-wipe" aria-hidden="true"></div>
    <div class="scene__meta"><span>consulta de visita</span></div>
    <div class="confirm-copy"><p class="kicker">Tu visita</p><h2 id="confirm-title"><span id="summary-day">DÍA</span><em id="summary-time">FRANJA</em></h2><p>${esc(L.address)}<br>${esc(L.city)}</p></div>
    <div class="confirm-actions">${reservaBtn}<a class="secondary" href="${esc(L.mapsUrl)}" ${EXT}>Abrir Maps</a><button id="restart" class="secondary" type="button">Elegir otro día</button></div>
    <p id="send-state" class="send-state" role="status" aria-live="polite" data-state="ready">Listo para copiar · lo mandás vos por Facebook o Instagram</p>
    <p class="disclaimer">Con este mensaje consultás por una visita. El día y la hora se acuerdan con ${esc(NAME)}.</p>
    ${demo ? '<p class="disclaimer" data-demo-note>Versión de demostración · No es el sitio oficial · Datos pendientes de confirmación</p>' : ''}
  </section>
  <div id="live" class="sr-only" aria-live="polite"></div>
</main>
<script type="module" src="js/reserva.js"></script><script type="module" src="js/motion.js"></script>
</body>
</html>
`;

write('index.html', index);
write('reserva.html', reserva);
write('privacidad.html', privacidad);
write('404.html', nf);
write('robots.txt', demo ? 'User-agent: *\nDisallow: /\n' : `User-agent: *\nAllow: /\n${siteUrl ? `Sitemap: ${siteUrl}sitemap.xml\n` : ''}`);
const smPath = path.join(root, 'sitemap.xml');
if (!demo && siteUrl) write('sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${siteUrl}</loc></url>\n  <url><loc>${siteUrl}reserva.html</loc></url>\n  <url><loc>${siteUrl}privacidad.html</loc></url>\n</urlset>\n`);
else if (fs.existsSync(smPath)) fs.rmSync(smPath);
write('site.webmanifest', JSON.stringify({ name: NAME, short_name: 'Horizonte', description: `Autos y motos en ${L.city}, ${L.province}.`, lang: 'es-AR', start_url: './', scope: './', display: 'standalone', background_color: '#0a1012', theme_color: '#0a1012', icons: [{ src: 'images/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' }, { src: 'images/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' }] }, null, 2) + '\n');
write('favicon.svg', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="10" fill="#0a1012"/><path d="M9 44a23 23 0 0 1 46 0z" fill="#f2d21b"/><path d="M25 28v14M39 28v14M25 35h14" stroke="#0a1012" stroke-width="4.5" fill="none"/><path d="M6 50h52" stroke="#fff" stroke-width="4" fill="none"/></svg>\n');

console.log(`Generado: index.html (${(index.length / 1024).toFixed(1)} KB), privacidad.html, reserva.html, 404.html · ${autos.length} unidades · modo ${demo ? 'demo (noindex)' : 'producción'}`);
